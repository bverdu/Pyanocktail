'''
pyanocktaild multiservice
'''